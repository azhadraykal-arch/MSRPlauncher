package com.mnrp.launcher

/** UBAH NILAI DI SINI sesuai server kalian. */
object Config {
    const val SERVER_NAME = "Malaysia Nusantara Roleplay"
    const val SERVER_IP = "127.0.0.1"          // GANTI: IP server (IPv4)
    const val SERVER_PORT = 7777               // GANTI: port server
    const val DISCORD_URL = "https://discord.gg/GANTI"
    const val CLIENT_PACKAGE = "com.samp.mobile" // GANTI: package client resmi server
    const val CLIENT_DOWNLOAD_URL = "https://example.com/download" // GANTI
}
