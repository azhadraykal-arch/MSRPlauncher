package com.mnrp.launcher

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var tvStatus: TextView
    private lateinit var tvPlayers: TextView
    private lateinit var etNick: EditText
    private val prefs by lazy { getSharedPreferences("mnrp", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvStatus = findViewById(R.id.tvStatus)
        tvPlayers = findViewById(R.id.tvPlayers)
        etNick = findViewById(R.id.etNick)
        etNick.setText(prefs.getString("nick", ""))
        findViewById<TextView>(R.id.tvAddress).text = "${Config.SERVER_IP}:${Config.SERVER_PORT}"

        findViewById<Button>(R.id.btnPlay).setOnClickListener { play() }
        findViewById<Button>(R.id.btnCopy).setOnClickListener {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("ip", "${Config.SERVER_IP}:${Config.SERVER_PORT}"))
            toast("IP disalin")
        }
        findViewById<Button>(R.id.btnDiscord).setOnClickListener { open(Config.DISCORD_URL) }
        findViewById<Button>(R.id.btnRefresh).setOnClickListener { refresh() }
        refresh()
    }

    private fun play() {
        val nick = etNick.text.toString().trim()
        if (!Regex("^[A-Za-z0-9_\\[\\]$=@.()]{3,20}$").matches(nick)) {
            toast("Nickname 3-20 karakter (huruf, angka, _)"); return
        }
        prefs.edit().putString("nick", nick).apply()
        val intent = packageManager.getLaunchIntentForPackage(Config.CLIENT_PACKAGE)
        if (intent != null) startActivity(intent)
        else { toast("Client belum terpasang, membuka halaman unduhan"); open(Config.CLIENT_DOWNLOAD_URL) }
    }

    private fun refresh() {
        tvStatus.text = "Memeriksa server..."
        Thread {
            val info = ServerQuery.query(Config.SERVER_IP, Config.SERVER_PORT)
            runOnUiThread {
                if (info == null) {
                    tvStatus.text = "● OFFLINE"; tvStatus.setTextColor(0xFFE53935.toInt())
                    tvPlayers.text = "-"
                } else {
                    tvStatus.text = "● ONLINE  (${info.pingMs} ms)"; tvStatus.setTextColor(0xFF43A047.toInt())
                    tvPlayers.text = "${info.players} / ${info.maxPlayers} pemain"
                }
            }
        }.start()
    }

    private fun open(url: String) = startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
