package com.mnrp.launcher

import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class ServerInfo(val players: Int, val maxPlayers: Int, val hostname: String, val pingMs: Long)

/** Query protokol SA-MP (UDP, opcode 'i') untuk status server. Panggil dari background thread. */
object ServerQuery {
    fun query(host: String, port: Int): ServerInfo? = try {
        DatagramSocket().use { s ->
            s.soTimeout = 3000
            val addr = InetAddress.getByName(host)
            val ip = addr.address
            if (ip.size != 4) return null
            val req = ByteBuffer.allocate(11).apply {
                put("SAMP".toByteArray()); put(ip)
                put((port and 0xFF).toByte()); put(((port shr 8) and 0xFF).toByte())
                put('i'.code.toByte())
            }.array()
            val start = System.currentTimeMillis()
            s.send(DatagramPacket(req, req.size, addr, port))
            val buf = ByteArray(1024)
            val pkt = DatagramPacket(buf, buf.size)
            s.receive(pkt)
            val ping = System.currentTimeMillis() - start
            val b = ByteBuffer.wrap(buf, 0, pkt.length).order(ByteOrder.LITTLE_ENDIAN)
            b.position(11)
            b.get() // password flag
            val players = b.short.toInt() and 0xFFFF
            val max = b.short.toInt() and 0xFFFF
            val len = b.int
            val name = ByteArray(len).also { b.get(it) }
            ServerInfo(players, max, String(name, Charsets.ISO_8859_1), ping)
        }
    } catch (e: Exception) { null }
}
